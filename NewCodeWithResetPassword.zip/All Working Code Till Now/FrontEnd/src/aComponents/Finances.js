function Finances() {
    return ( 
    <>
        <div className="page-header">
        <h1> Hospital Finances</h1>
        </div>
    </>
        

     );
}

export default Finances;
