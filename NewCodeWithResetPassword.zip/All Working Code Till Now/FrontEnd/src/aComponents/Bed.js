function Bed() {
    return ( 
    <>
        <div className="page-header">
        <h1> Bed Availiability</h1>
        </div>
    </>
        

     );
}

export default Bed;
