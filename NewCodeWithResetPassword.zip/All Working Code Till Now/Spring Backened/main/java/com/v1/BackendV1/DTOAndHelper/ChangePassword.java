package com.v1.BackendV1.DTOAndHelper;

public class ChangePassword {
    String managementPassword;
    String managementNewPassword;

    public String getManagementPassword() {
        return managementPassword;
    }

    public void setManagementPassword(String managementPassword) {
        this.managementPassword = managementPassword;
    }

    public String getManagementNewPassword() {
        return managementNewPassword;
    }

    public void setManagementNewPassword(String managementNewPassword) {
        this.managementNewPassword = managementNewPassword;
    }
}
