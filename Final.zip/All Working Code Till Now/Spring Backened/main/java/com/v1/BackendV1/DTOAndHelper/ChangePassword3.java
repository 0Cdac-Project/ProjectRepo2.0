package com.v1.BackendV1.DTOAndHelper;

public class ChangePassword3 {
    String doctorPassword;
    String doctorNewPassword;

    public String getDoctorPassword() {
        return doctorPassword;
    }

    public void setDoctorPassword(String doctorPassword) {
        this.doctorPassword = doctorPassword;
    }

    public String getDoctorNewPassword() {
        return doctorNewPassword;
    }

    public void setDoctorNewPassword(String doctorNewPassword) {
        this.doctorNewPassword = doctorNewPassword;
    }
}
