import axios from "axios";
import { useState } from "react";
import { useSelector } from "react-redux";
import { selectUser } from "../Redux/Reducer/userslice";

function PatientsHistory() {
  const user1 = useSelector(selectUser);
  const [appointments, setAppointments] = useState([]);
  const [readOnly, setReadOnly] = useState(true);
  const [patientId, setPatientId] = useState(0);
  const url = `http://localhost:8080/api/v1/appointments/by_patient/${patientId}/${user1.doctorID}`;

  const loadData = () => {
    axios.get(url).then((response) => {
      console.log(response.data);
      setAppointments(response.data);
    });
  };

  const onTextChange = (args) => {
    setPatientId(args.target.value);
  };
  const user = useSelector(selectUser);

  return (
    <>
      <div className="page-header">
        <h1>Patients History</h1>
        <input
          // id="search-box"
          placeholder="Enter Patient Id"
          type="text"
          value={patientId}
          onChange={onTextChange}
        />
        <button className="" onClick={loadData}>
          Search
        </button>
      </div>
      {/*
        <div className="table-responsive">
          <table className="fl-table">
            <thead>
              <tr>
                <th>Id</th>
                <th>Appointment Date</th>
                <th>Patient Name</th>
                <th>Doctor Name</th>
                <th>Medical condition</th>
                <th>Medication</th>
                <th>Patient Blood group</th>
                <th>Patient Medication History</th>
                <th>Patient Weight</th>
              </tr>
            </thead>
            <tbody>
              {
                appointments.map((res, index)=>{
                  return (
                    <tr key={index}>
                      <td>{res.appointmentID}</td>
                      <td>{res.appointmentDateTime}</td>
                      <td>
                        {res.patient.patientFirstName +
                          " " +
                          res.patient.patientLastName}
                      </td>
                      <td>
                        {res.doctor.doctorFirstName +
                          " " +
                          res.doctor.doctorLastName}
                      </td>
                      <td>{res.medicalCondition}</td>
                      <td>{res.medication}</td>
                      <td>{res.patient.patientBloodgroup}</td>
                      <td>{res.patient.patientMedicationHistory}</td>
                      <td>{res.patient.patientWeight}</td>
                    </tr>
                  )
                })
              }
            </tbody>
          </table>
        </div> */}
        {appointments.length==0 ?<h1>Enter Valid Patient Id</h1>:
      <div className="page-content">
        <div className="container">
          <div className="main-body">
            <div className="row">
              <div className="col-lg-4">
                <div className="card">
                  <div className="card-body">
                    <div className="d-flex flex-column align-items-center text-center">
                      <div
                        className="bg-img"
                        style={{
                          width: "120px",
                          height: "120px",
                          borderRadius: "50%",
                          overflow: "hidden",
                        }}
                      >
                        <img
                          src={`data:image/jpeg;base64, ${appointments.patient.patientImage}`}
                          alt="Admin"
                          className="rounded-circle"
                          style={{
                            width: "100%",
                            height: "100%",
                            objectFit: "cover",
                          }}
                        />
                      </div>
                      <div className="mt-3">
                        <h4>
                          {appointments.patient.patientFirstName} {appointments.patient.patientLastName}
                        </h4>
                        <p className="text-muted font-size-sm">
                          Username - {appointments.patient.patientUsername}
                        </p>
                      </div>
                    </div>
                    <hr className="my-4" />
                    <ul className="list-group list-group-flush">
                      <li className="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                        <h6 className="mb-0">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="appointments.patiententColor"
                            stroke-width="2"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            className="feather feather-globe me-2 icon-inline"
                          >
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="2" y1="12" x2="22" y2="12"></line>
                            <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                          </svg>
                          Email
                        </h6>
                        <span className="text-secondary">
                          {appointments.patient.patientEmail}
                        </span>
                      </li>
                      <li className="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                        <h6 className="mb-0">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="appointments.patiententColor"
                            stroke-width="2"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            className="feather feather-github me-2 icon-inline"
                          >
                            <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path>
                          </svg>
                          Phone
                        </h6>
                        <span className="text-secondary">
                          {appointments.patient.patientMobile}
                        </span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="col-lg-4">
                <div className="card">
                  <div className="card-body">
                    <div className="row mb-3">
                      <div className="col-sm-5">
                        <h6 className="mb-0">Date of birth</h6>
                      </div>
                      <div className="col-sm-7 text-secondary">
                        <input
                          readOnly
                          type="date"
                          className="form-control"
                          value={appointments.patient.patientDob}
                          name="patientDob"
                        />
                      </div>
                    </div>
                    <div className="row mb-3">
                      <div className="col-sm-5">
                        <h6 className="mb-0">Gender</h6>
                      </div>
                      <div className="col-sm-7 text-secondary">
                        <select
                          className="form-select"
                          id="patientGender"
                          aria-label="Floating label select example"
                          name="patientGender"
                          value={appointments.patient.patientGender}
                        >
                          <option value="" disabled defaultValue>
                            Select Gender
                          </option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>
                    </div>
                    <div className="row mb-3">
                      <div className="col-sm-5">
                        <h6 className="mb-0">Emergency Contact</h6>
                      </div>
                      <div className="col-sm-7 text-secondary">
                        <input
                          readOnly
                          type="text"
                          className="form-control"
                          value={appointments.patient.patientEmergencyContact}
                          name="patientEmergencyContact"
                        />
                      </div>
                    </div>
                    <div className="row mb-3">
                      <div className="col-sm-5">
                        <h6 className="mb-0">Address</h6>
                      </div>
                      <div className="col-sm-7 text-secondary">
                        <textarea
                          readOnly
                          className="form-control"
                          placeholder="Address here"
                          id="patientAddress"
                          style={{ height: "100px" }}
                          name="patientAddress"
                          value={appointments.patient.patientAddress}
                        ></textarea>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-4">
                <div className="card">
                  <div className="card-body">
                    <div className="row mb-3">
                      <div className="col-sm-5">
                        <h6 className="mb-0">Occupation</h6>
                      </div>
                      <div className="col-sm-7 text-secondary">
                        <input
                          readOnly
                          type="text"
                          className="form-control"
                          value={appointments.patient.patientOccupation}
                          name="patientOccupation"
                        />
                      </div>
                    </div>
                    <div className="row mb-3">
                      <div className="col-sm-5">
                        <h6 className="mb-0">Medication History</h6>
                      </div>
                      <div className="col-sm-7 text-secondary">
                        <input
                          readOnly
                          type="text"
                          className="form-control"
                          value={appointments.patient.patientMedicationHistory}
                          name="patientMedicationHistory"
                        />
                      </div>
                    </div>
                    <div className="row mb-3">
                      <div className="col-sm-5">
                        <h6 className="mb-0">Blood Group</h6>
                      </div>
                      <div className="col-sm-7 text-secondary">
                        <select
                          className="form-select"
                          id="patientGender"
                          aria-label="Floating label select example"
                          name="patientBloodgroup"
                          value={appointments.patient.patientBloodgroup}
                        >
                          <option value="" disabled defaultValue>
                            Select Blood Group
                          </option>
                          <option value="AB+">AB+</option>
                          <option value="AB-">AB-</option>
                          <option value="A+">A+</option>
                          <option value="A-">A-</option>
                          <option value="B+">B+</option>
                          <option value="B-">B-</option>
                          <option value="O+">O+</option>
                          <option value="O-">O-</option>
                        </select>
                      </div>
                    </div>
                    <div className="row mb-3">
                      <div className="col-sm-5">
                        <h6 className="mb-0">Weight</h6>
                      </div>
                      <div className="col-sm-7 text-secondary">
                        <input
                          readOnly
                          type="number"
                          className="form-control"
                          value={appointments.patient.patientWeight}
                          name="patientWeight"
                        />
                      </div>
                    </div>
                    <div className="row mb-3">
                      <div className="col-sm-5">
                        <h6 className="mb-0">Height</h6>
                      </div>
                      <div className="col-sm-7 text-secondary">
                        <input
                          readOnly
                          type="number"
                          className="form-control"
                          value={appointments.patient.patientHeight}
                          name="patientHeight"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
}
    </>
  );
}

export default PatientsHistory;
