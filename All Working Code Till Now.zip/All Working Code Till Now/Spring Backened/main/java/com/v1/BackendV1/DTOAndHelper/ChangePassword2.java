package com.v1.BackendV1.DTOAndHelper;

public class ChangePassword2 {
    String patientPassword;
    String patientNewPassword;

    public String getPatientPassword() {
        return patientPassword;
    }

    public void setPatientPassword(String patientPassword) {
        this.patientPassword = patientPassword;
    }

    public String getPatientNewPassword() {
        return patientNewPassword;
    }

    public void setPatientNewPassword(String patientNewPassword) {
        this.patientNewPassword = patientNewPassword;
    }
}
