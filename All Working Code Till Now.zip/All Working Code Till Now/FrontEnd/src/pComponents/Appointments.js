function Appointments() {
    return ( 
        <div className="page-header">
            <h1>Appointments</h1>
        </div>
     );
}

export default Appointments;