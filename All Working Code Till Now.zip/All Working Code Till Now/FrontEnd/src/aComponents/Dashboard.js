function Dashboard() {
    return ( 
    <>
        <div className="page-header">
        <h1> Dashboard / Schedule Page</h1>
        </div>
    </>
        

     );
}

export default Dashboard;
