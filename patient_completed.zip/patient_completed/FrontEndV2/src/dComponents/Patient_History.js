function PatientsHistory() {
    return ( 
        <div className="page-header">
            <h1>Patients History</h1>
        </div>
     );
}

export default PatientsHistory;