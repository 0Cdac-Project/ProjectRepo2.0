import PatientDtls from '../aComponents/Patient'

function PatientsDetails() {
    return ( 
        <PatientDtls />
     );
}

export default PatientsDetails;