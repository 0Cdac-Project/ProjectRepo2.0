package com.v1.BackendV1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
