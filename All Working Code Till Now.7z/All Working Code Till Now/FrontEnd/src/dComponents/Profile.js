function Profile() {
    return ( 
        <>
          <div className="page-header"><h1>Doctors Profile Page</h1></div>
        </>
     );
}

export default Profile;