package com.v1.BackendV1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendV1Application {

	public static void main(String[] args) {
		SpringApplication.run(BackendV1Application.class, args);
	}

}
