function Dashboard() {
    return ( 
    <>
        <div className="page-header">
        <h1> Dashboard</h1>
        </div>
    </>
     );
}

export default Dashboard;
