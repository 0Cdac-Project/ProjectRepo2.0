function Finance() {
    return ( 
    <>
        <div className="page-header">
        <h1> Finance</h1>
        </div>
    </>
     );
}

export default Finance;
