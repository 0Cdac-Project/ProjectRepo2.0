function AppointmentHistory() {
    return ( 
        <>
            <div className="page-header">
                <h1>Appointments History</h1>
            </div>
        </>
     );
}

export default AppointmentHistory;