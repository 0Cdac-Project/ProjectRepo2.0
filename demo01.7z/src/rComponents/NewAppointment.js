function NewAppointment() {
    return ( 
        <>
            <div className="page-header">
                <h1>Appointments Add New</h1>
            </div>
        </>
     );
}

export default NewAppointment;